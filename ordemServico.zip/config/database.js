// config/database.js
module.exports = {
	// 'url' : 'mongodb://localhost:27017/authdb'
	'url' : 'mongodb://localhost:27017/projeto_senac'
	// looks like mongodb://<user>:<pass>@mongo.onmodulus.net:27017/Mikha4ot
};
